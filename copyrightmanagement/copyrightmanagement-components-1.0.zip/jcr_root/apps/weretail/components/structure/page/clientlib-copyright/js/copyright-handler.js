(function($, $document) {

    "use strict";

    $document.on("foundation-contentloaded", function() { 
        var cfinput = $('input[name="./copyrightcfdata"]');
        var variationInput = $('coral-select[name="./copyrightcfvariation"]');
        var oldCFValue = $('input[name="./copyrightcfdata"]').val(); 

        if (typeof cfinput !== undefined) {

            $('foundation-autocomplete[name="./copyrightcfdata"]>div>div>input').blur(function(event) {

                var cfFile = $('input[name="./copyrightcfdata"]').val();
                if (oldCFValue != cfFile) {
                    updateChange(cfFile);
                }

            });
 

            $('foundation-autocomplete[name="./copyrightcfdata"]>div>div>input').focus(function(event) {
                oldCFValue = $('input[name="./copyrightcfdata"]').val();

            });
        } 

        // on load

        var cfFile = $('coral-taglist[name="./copyrightcfdata"]>coral-tag').val();
        updateChange(cfFile);
        setTimeout(updateSelectedVariationVal, 100); 

        // on select val
        function updateSelectedVariationVal() {
          var url = $('.foundation-form')[0].action+'.-1.json'
           $.ajax({

                type: "GET",
                url: url,
                success: function(data) {
                    if (typeof data.copyrightcfvariation !== undefined) {

                        variationInput.each(function(idx, select) {
                            select.items.getAll().forEach(function(item, idx) {
                                if (item.value === data.copyrightcfvariation) {
                                    item.selected = true;
                                }
                            });
                        });
                    }
                },

                error: function(XMLHttpRequest, textStatus, errorThrown) {}

            });

        }
 

        function updateChange(cfFile) {

            var url = cfFile + ".cfm.info.json?ck=" + Math.random();

            $.ajax({
                type: "GET",
                url: url,
                success: function(data) {
                    if (typeof data.variations !== undefined) {
                        if (variationInput[0] != undefined) {
                            variationInput[0].items.clear();
                            variationInput[0].items.add({
                                value: '',
                                content: {
                                    innerHTML: 'Please Select Variation'
                                },

                                disabled: false,
                            }); 


                            for (var i in data.variations) {
                                variationInput[0].items.add({
                                    content: {
                                        innerHTML: data.variations[i].name
                                    },

                                    disabled: false,
                                });

                            }
                        }

                    }

                },

                error: function(XMLHttpRequest, textStatus, errorThrown) {

                    if (variationInput[0] != undefined) {
                        variationInput[0].items.clear();
                        variationInput[0].items.add({
                            value: '',
                            content: {
                                innerHTML: 'Please Select Variation'
                            },
                            disabled: false,
                       });
                    }
                }
            });
        }
    });

})($, $(document));
