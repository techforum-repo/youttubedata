(function (document, $, Coral) {

  var $doc = $(document);

 $doc.on('foundation-contentloaded', function(e) { 

 	var coralTab = $(".tabtest coral-tablist coral-tab");
    coralTab[1].hide();

     console.log(coralTab[1].get);

$('.presets', e.target).each(function (i, element) {

            Coral.commons.ready(element, function (component) {

                $(component).on("change",function (event) {

                     var coralTab = $(".tabtest coral-tablist coral-tab");
                     coralTab[1].show();

                });


            });


        });

  });
})(document, Granite.$, Coral);