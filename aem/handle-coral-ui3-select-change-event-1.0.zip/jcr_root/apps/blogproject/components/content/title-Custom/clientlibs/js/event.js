(function (document, $, Coral) {
var $doc = $(document);
	$doc.on('foundation-contentloaded', function(e) {

	$('.columns').parent().addClass("hide"); 

	$('.presets', e.target).each(function (i, element) {

		Coral.commons.ready(element, function (component) {

			$(component).on("change",function (event) {

				if(component.value=='Advanced')
				{
					$('.columns').parent().removeClass("hide");
					$('.title').prop('checked', true);
				}else
				{
					$('.columns').parent().addClass("hide");
					$('.title').prop('checked', false);
				}
			});
		});


	});
	});
})(document, Granite.$, Coral);